<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Customer extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data customer
    function index_get() {
        $nama = $this->get('nama');
        if ($nama == '') {
 $customer = $this->db->get('customer')->result();
        } else {
            $this->db->where('nama', $nama);
            $customer= $this->db->get('customer')->result();
        }
        $this->response($customer, 200);
    }

    // insert new data to customer
    function index_post() {
        $data = array(
                    'nama'           => $this->post('nama'),
                    'telepon'          => $this->post('telepon'),
                    'alamat'    => $this->post('alamat'),
                    'email'        => $this->post('email'));
        $insert = $this->db->insert('customer', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    // update data customer
    function index_put() {
        $nama = $this->put('nama');
        $data = array(
                    'nama'       => $this->put('nama'),
                    'telepon'      => $this->put('telepon'),
                    'alamat'=> $this->put('alamat'),
                    'email'    => $this->put('email'));
        $this->db->where('nama', $nama);
        $update = $this->db->update('customer', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }

    // delete customer
    function index_delete() {
        $nama = $this->delete('nama');
        $this->db->where('nama', $nama);
        $delete = $this->db->delete('customer');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
			}
}
}
?>